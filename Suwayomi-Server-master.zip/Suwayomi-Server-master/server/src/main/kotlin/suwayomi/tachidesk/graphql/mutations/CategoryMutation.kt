@file:Suppress("RedundantNullableReturnType", "unused")

package suwayomi.tachidesk.graphql.mutations

import org.jetbrains.exposed.v1.core.LikePattern
import org.jetbrains.exposed.v1.core.Op
import org.jetbrains.exposed.v1.core.and
import org.jetbrains.exposed.v1.core.eq
import org.jetbrains.exposed.v1.core.greaterEq
import org.jetbrains.exposed.v1.core.inList
import org.jetbrains.exposed.v1.core.lessEq
import org.jetbrains.exposed.v1.core.like
import org.jetbrains.exposed.v1.core.minus
import org.jetbrains.exposed.v1.core.or
import org.jetbrains.exposed.v1.core.plus
import org.jetbrains.exposed.v1.jdbc.deleteWhere
import org.jetbrains.exposed.v1.jdbc.insertAndGetId
import org.jetbrains.exposed.v1.jdbc.selectAll
import org.jetbrains.exposed.v1.jdbc.transactions.transaction
import org.jetbrains.exposed.v1.jdbc.update
import suwayomi.tachidesk.graphql.directives.RequireAuth
import suwayomi.tachidesk.graphql.types.CategoryMetaType
import suwayomi.tachidesk.graphql.types.CategoryType
import suwayomi.tachidesk.graphql.types.MangaType
import suwayomi.tachidesk.graphql.types.MetaInput
import suwayomi.tachidesk.manga.impl.Category
import suwayomi.tachidesk.manga.impl.CategoryManga
import suwayomi.tachidesk.manga.impl.util.lang.isEmpty
import suwayomi.tachidesk.manga.model.dataclass.IncludeOrExclude
import suwayomi.tachidesk.manga.model.table.CategoryMangaTable
import suwayomi.tachidesk.manga.model.table.CategoryMetaTable
import suwayomi.tachidesk.manga.model.table.CategoryTable
import suwayomi.tachidesk.manga.model.table.MangaTable

class CategoryMutation {
    data class SetCategoryMetaInput(
        val clientMutationId: String? = null,
        val meta: CategoryMetaType,
    )

    data class SetCategoryMetaPayload(
        val clientMutationId: String?,
        val meta: CategoryMetaType,
    )

    @RequireAuth
    fun setCategoryMeta(input: SetCategoryMetaInput): SetCategoryMetaPayload? {
        val (clientMutationId, meta) = input

        Category.modifyMeta(meta.categoryId, meta.key, meta.value)

        return SetCategoryMetaPayload(clientMutationId, meta)
    }

    data class DeleteCategoryMetaInput(
        val clientMutationId: String? = null,
        val categoryId: Int,
        val key: String,
    )

    data class DeleteCategoryMetaPayload(
        val clientMutationId: String?,
        val meta: CategoryMetaType?,
        val category: CategoryType,
    )

    @RequireAuth
    fun deleteCategoryMeta(input: DeleteCategoryMetaInput): DeleteCategoryMetaPayload? {
        val (clientMutationId, categoryId, key) = input

        val (meta, category) =
            transaction {
                val meta =
                    CategoryMetaTable
                        .selectAll()
                        .where { (CategoryMetaTable.ref eq categoryId) and (CategoryMetaTable.key eq key) }
                        .firstOrNull()

                CategoryMetaTable.deleteWhere { (CategoryMetaTable.ref eq categoryId) and (CategoryMetaTable.key eq key) }

                val category =
                    transaction {
                        CategoryType(CategoryTable.selectAll().where { CategoryTable.id eq categoryId }.first())
                    }

                if (meta != null) {
                    CategoryMetaType(meta)
                } else {
                    null
                } to category
            }

        return DeleteCategoryMetaPayload(clientMutationId, meta, category)
    }

    data class SetCategoryMetasItem(
        val categoryIds: List<Int>,
        val metas: List<MetaInput>,
    )

    data class SetCategoryMetasInput(
        val clientMutationId: String? = null,
        val items: List<SetCategoryMetasItem>,
    )

    data class SetCategoryMetasPayload(
        val clientMutationId: String?,
        val metas: List<CategoryMetaType>,
        val categories: List<CategoryType>,
    )

    @RequireAuth
    fun setCategoryMetas(input: SetCategoryMetasInput): SetCategoryMetasPayload? {
        val (clientMutationId, items) = input

        val metaByCategoryId =
            items
                .flatMap { item ->
                    val metaMap = item.metas.associate { it.key to it.value }
                    item.categoryIds.map { categoryId -> categoryId to metaMap }
                }.groupBy({ it.first }, { it.second })
                .mapValues { (_, maps) -> maps.reduce { acc, map -> acc + map } }

        Category.modifyCategoriesMetas(metaByCategoryId)

        val allCategoryIds = metaByCategoryId.keys
        val allMetaKeys = metaByCategoryId.values.flatMap { item -> item.keys }.distinct()

        val (updatedMetas, categories) =
            transaction {
                val updatedMetas =
                    CategoryMetaTable
                        .selectAll()
                        .where { (CategoryMetaTable.ref inList allCategoryIds) and (CategoryMetaTable.key inList allMetaKeys) }
                        .map { CategoryMetaType(it) }

                val categories =
                    CategoryTable
                        .selectAll()
                        .where { CategoryTable.id inList allCategoryIds }
                        .map { CategoryType(it) }
                        .distinctBy { it.id }

                updatedMetas to categories
            }

        return SetCategoryMetasPayload(clientMutationId, updatedMetas, categories)
    }

    data class DeleteCategoryMetasItem(
        val categoryIds: List<Int>,
        val keys: List<String>? = null,
        val prefixes: List<String>? = null,
    )

    data class DeleteCategoryMetasInput(
        val clientMutationId: String? = null,
        val items: List<DeleteCategoryMetasItem>,
    )

    data class DeleteCategoryMetasPayload(
        val clientMutationId: String?,
        val metas: List<CategoryMetaType>,
        val categories: List<CategoryType>,
    )

    @RequireAuth
    fun deleteCategoryMetas(input: DeleteCategoryMetasInput): DeleteCategoryMetasPayload? {
        val (clientMutationId, items) = input

        items.forEach { item ->
            require(!item.keys.isNullOrEmpty() || !item.prefixes.isNullOrEmpty()) {
                "Either 'keys' or 'prefixes' must be provided for each item"
            }
        }

        val (allDeletedMetas, allCategoryIds) =
            transaction {
                val deletedMetas = mutableListOf<CategoryMetaType>()
                val categoryIds = mutableSetOf<Int>()

                items.forEach { item ->
                    val keyCondition: Op<Boolean>? =
                        item.keys?.takeIf { it.isNotEmpty() }?.let { CategoryMetaTable.key inList it }

                    val prefixCondition: Op<Boolean>? =
                        item.prefixes
                            ?.filter { it.isNotEmpty() }
                            ?.map { (CategoryMetaTable.key like LikePattern("$it%")) as Op<Boolean> }
                            ?.reduceOrNull { acc, op -> acc or op }

                    val metaKeyCondition =
                        if (keyCondition != null && prefixCondition != null) {
                            keyCondition or prefixCondition
                        } else {
                            keyCondition ?: prefixCondition!!
                        }

                    val condition = (CategoryMetaTable.ref inList item.categoryIds) and metaKeyCondition

                    deletedMetas +=
                        CategoryMetaTable
                            .selectAll()
                            .where { condition }
                            .map { CategoryMetaType(it) }

                    CategoryMetaTable.deleteWhere { condition }
                    categoryIds += item.categoryIds
                }

                deletedMetas to categoryIds
            }

        val categories =
            transaction {
                CategoryTable
                    .selectAll()
                    .where { CategoryTable.id inList allCategoryIds }
                    .map { CategoryType(it) }
                    .distinctBy { it.id }
            }

        return DeleteCategoryMetasPayload(clientMutationId, allDeletedMetas, categories)
    }

    data class UpdateCategoryPatch(
        val name: String? = null,
        val default: Boolean? = null,
        val includeInUpdate: IncludeOrExclude? = null,
        val includeInDownload: IncludeOrExclude? = null,
    )

    data class UpdateCategoryPayload(
        val clientMutationId: String?,
        val category: CategoryType,
    )

    data class UpdateCategoryInput(
        val clientMutationId: String? = null,
        val id: Int,
        val patch: UpdateCategoryPatch,
    )

    data class UpdateCategoriesPayload(
        val clientMutationId: String?,
        val categories: List<CategoryType>,
    )

    data class UpdateCategoriesInput(
        val clientMutationId: String? = null,
        val ids: List<Int>,
        val patch: UpdateCategoryPatch,
    )

    private fun updateCategories(
        ids: List<Int>,
        patch: UpdateCategoryPatch,
    ) {
        transaction {
            if (patch.name != null) {
                CategoryTable.update({ CategoryTable.id inList ids }) { update ->
                    patch.name.also {
                        update[name] = it
                    }
                }
            }
            if (patch.default != null) {
                CategoryTable.update({ CategoryTable.id inList ids }) { update ->
                    patch.default.also {
                        update[isDefault] = it
                    }
                }
            }
            if (patch.includeInUpdate != null) {
                CategoryTable.update({ CategoryTable.id inList ids }) { update ->
                    patch.includeInUpdate.also {
                        update[includeInUpdate] = it.value
                    }
                }
            }
            if (patch.includeInDownload != null) {
                CategoryTable.update({ CategoryTable.id inList ids }) { update ->
                    patch.includeInDownload.also {
                        update[includeInDownload] = it.value
                    }
                }
            }
        }
    }

    @RequireAuth
    fun updateCategory(input: UpdateCategoryInput): UpdateCategoryPayload? {
        val (clientMutationId, id, patch) = input

        updateCategories(listOf(id), patch)

        val category =
            transaction {
                CategoryType(CategoryTable.selectAll().where { CategoryTable.id eq id }.first())
            }

        return UpdateCategoryPayload(
            clientMutationId = clientMutationId,
            category = category,
        )
    }

    @RequireAuth
    fun updateCategories(input: UpdateCategoriesInput): UpdateCategoriesPayload? {
        val (clientMutationId, ids, patch) = input

        updateCategories(ids, patch)

        val categories =
            transaction {
                CategoryTable.selectAll().where { CategoryTable.id inList ids }.map { CategoryType(it) }
            }

        return UpdateCategoriesPayload(
            clientMutationId = clientMutationId,
            categories = categories,
        )
    }

    data class UpdateCategoryOrderPayload(
        val clientMutationId: String?,
        val categories: List<CategoryType>,
    )

    data class UpdateCategoryOrderInput(
        val clientMutationId: String? = null,
        val id: Int,
        val position: Int,
    )

    @RequireAuth
    fun updateCategoryOrder(input: UpdateCategoryOrderInput): UpdateCategoryOrderPayload? {
        val (clientMutationId, categoryId, position) = input
        require(position > 0) {
            "'order' must not be <= 0"
        }

        transaction {
            val currentOrder =
                CategoryTable
                    .selectAll()
                    .where { CategoryTable.id eq categoryId }
                    .first()[CategoryTable.order]

            if (currentOrder != position) {
                if (position < currentOrder) {
                    CategoryTable.update({ CategoryTable.order greaterEq position }) {
                        it[CategoryTable.order] = CategoryTable.order + 1
                    }
                } else {
                    CategoryTable.update({ CategoryTable.order lessEq position }) {
                        it[CategoryTable.order] = CategoryTable.order - 1
                    }
                }

                CategoryTable.update({ CategoryTable.id eq categoryId }) {
                    it[CategoryTable.order] = position
                }
            }
        }

        Category.normalizeCategories()

        val categories =
            transaction {
                CategoryTable.selectAll().orderBy(CategoryTable.order).map { CategoryType(it) }
            }

        return UpdateCategoryOrderPayload(
            clientMutationId = clientMutationId,
            categories = categories,
        )
    }

    data class CreateCategoryInput(
        val clientMutationId: String? = null,
        val name: String,
        val order: Int? = null,
        val default: Boolean? = null,
        val includeInUpdate: IncludeOrExclude? = null,
        val includeInDownload: IncludeOrExclude? = null,
    )

    data class CreateCategoryPayload(
        val clientMutationId: String?,
        val category: CategoryType,
    )

    @RequireAuth
    fun createCategory(input: CreateCategoryInput): CreateCategoryPayload? {
        val (clientMutationId, name, order, default, includeInUpdate, includeInDownload) = input
        transaction {
            require(CategoryTable.selectAll().where { CategoryTable.name eq input.name }.isEmpty()) {
                "'name' must be unique"
            }
        }
        require(!name.equals(Category.DEFAULT_CATEGORY_NAME, ignoreCase = true)) {
            "'name' must not be ${Category.DEFAULT_CATEGORY_NAME}"
        }
        if (order != null) {
            require(order > 0) {
                "'order' must not be <= 0"
            }
        }

        val category =
            transaction {
                if (order != null) {
                    CategoryTable.update({ CategoryTable.order greaterEq order }) {
                        it[CategoryTable.order] = CategoryTable.order + 1
                    }
                }

                val id =
                    CategoryTable.insertAndGetId {
                        it[CategoryTable.name] = input.name
                        it[CategoryTable.order] = order ?: Int.MAX_VALUE
                        if (default != null) {
                            it[CategoryTable.isDefault] = default
                        }
                        if (includeInUpdate != null) {
                            it[CategoryTable.includeInUpdate] = includeInUpdate.value
                        }
                        if (includeInDownload != null) {
                            it[CategoryTable.includeInDownload] = includeInDownload.value
                        }
                    }

                Category.normalizeCategories()

                CategoryType(CategoryTable.selectAll().where { CategoryTable.id eq id }.first())
            }

        return CreateCategoryPayload(clientMutationId, category)
    }

    data class DeleteCategoryInput(
        val clientMutationId: String? = null,
        val categoryId: Int,
    )

    data class DeleteCategoryPayload(
        val clientMutationId: String?,
        val category: CategoryType?,
        val mangas: List<MangaType>,
    )

    @RequireAuth
    fun deleteCategory(input: DeleteCategoryInput): DeleteCategoryPayload? {
        val (clientMutationId, categoryId) = input
        if (categoryId == 0) { // Don't delete default category
            return DeleteCategoryPayload(
                clientMutationId,
                null,
                emptyList(),
            )
        }

        val (category, mangas) =
            transaction {
                val category =
                    CategoryTable
                        .selectAll()
                        .where { CategoryTable.id eq categoryId }
                        .firstOrNull()

                val mangas =
                    transaction {
                        MangaTable
                            .innerJoin(CategoryMangaTable)
                            .selectAll()
                            .where { CategoryMangaTable.category eq categoryId }
                            .map { MangaType(it) }
                    }

                CategoryTable.deleteWhere { CategoryTable.id eq categoryId }

                Category.normalizeCategories()

                if (category != null) {
                    CategoryType(category)
                } else {
                    null
                } to mangas
            }

        return DeleteCategoryPayload(clientMutationId, category, mangas)
    }

    data class UpdateMangaCategoriesPatch(
        val clearCategories: Boolean? = null,
        val addToCategories: List<Int>? = null,
        val removeFromCategories: List<Int>? = null,
    )

    data class UpdateMangaCategoriesPayload(
        val clientMutationId: String?,
        val manga: MangaType,
    )

    data class UpdateMangaCategoriesInput(
        val clientMutationId: String? = null,
        val id: Int,
        val patch: UpdateMangaCategoriesPatch,
    )

    data class UpdateMangasCategoriesPayload(
        val clientMutationId: String?,
        val mangas: List<MangaType>,
    )

    data class UpdateMangasCategoriesInput(
        val clientMutationId: String? = null,
        val ids: List<Int>,
        val patch: UpdateMangaCategoriesPatch,
    )

    private fun updateMangas(
        ids: List<Int>,
        patch: UpdateMangaCategoriesPatch,
    ) {
        transaction {
            if (patch.clearCategories == true) {
                CategoryMangaTable.deleteWhere { CategoryMangaTable.manga inList ids }
            } else if (!patch.removeFromCategories.isNullOrEmpty()) {
                CategoryMangaTable.deleteWhere {
                    (CategoryMangaTable.manga inList ids) and (CategoryMangaTable.category inList patch.removeFromCategories)
                }
            }
            if (!patch.addToCategories.isNullOrEmpty()) {
                CategoryManga.addMangasToCategories(ids, patch.addToCategories)
            }
        }
    }

    @RequireAuth
    fun updateMangaCategories(input: UpdateMangaCategoriesInput): UpdateMangaCategoriesPayload? {
        val (clientMutationId, id, patch) = input

        updateMangas(listOf(id), patch)

        val manga =
            transaction {
                MangaType(MangaTable.selectAll().where { MangaTable.id eq id }.first())
            }

        return UpdateMangaCategoriesPayload(
            clientMutationId = clientMutationId,
            manga = manga,
        )
    }

    @RequireAuth
    fun updateMangasCategories(input: UpdateMangasCategoriesInput): UpdateMangasCategoriesPayload? {
        val (clientMutationId, ids, patch) = input

        updateMangas(ids, patch)

        val mangas =
            transaction {
                MangaTable.selectAll().where { MangaTable.id inList ids }.map { MangaType(it) }
            }

        return UpdateMangasCategoriesPayload(
            clientMutationId = clientMutationId,
            mangas = mangas,
        )
    }
}
